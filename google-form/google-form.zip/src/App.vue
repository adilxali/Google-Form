<script setup>
import { RouterLink, RouterView } from 'vue-router'
import FormView from './views/FormView.vue';
</script>

<template>
  
  <RouterView />
</template>
